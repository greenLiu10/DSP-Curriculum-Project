function waves = gen_wave_energy_exp(tone,scale,noctave,rising,rhythm,fs,energy)
    f = tone2freq(tone,scale,noctave,rising);
    t = linspace(0,rhythm,fs*rhythm);
    y = zeros(1,length(t));
    for n = 1:length(energy)
        y = y + energy(n) * sin(2*pi*f*n.*t);
    end
    waves = y.*exp(-t/rhythm);
end
